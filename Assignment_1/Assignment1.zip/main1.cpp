//Thomas Payne
//Assignment 1
//Zietz
#include <iostream>
#include "Assignment1.cpp"
using namespace std;

int main(int argc, char const *argv[]){
    findItems(argv[1]);
}
